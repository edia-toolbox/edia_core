using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using ViveSR.anipal.Eye;
using UXF;
using eDIA;

public class EyeTrackingVisualizer : MonoBehaviour {

	[Header("Gaze LineRenderer")]
	[SerializeField] private LineRenderer GazeRayRenderer;
	public float LengthOfRay = 3f;

    	void FixedUpdate() {
		Vector3 gazeOriginCombinedLocal = new Vector3(float.NaN, float.NaN, float.NaN);
		Vector3 gazeDirectionCombinedLocal = new Vector3(float.NaN, float.NaN, float.NaN);

		bool gaze = false;

		gaze = SRanipal_Eye_v2.GetGazeRay(0, out gazeOriginCombinedLocal, out gazeDirectionCombinedLocal);
		// if (gaze) return;

		GazeRayRenderer.enabled = gaze? true:false; 

		if (gaze)
		{
			Vector3 gazeOriginCombined = XRrigUtilities.GetXRcam().TransformPoint(gazeOriginCombinedLocal);
			Vector3 gazeDirectionCombined = XRrigUtilities.GetXRcam().TransformDirection(gazeDirectionCombinedLocal);

			// Debug.DrawRay(gazeOriginCombined, gazeDirectionCombined, Color.red);
			GazeRayRenderer.SetPosition(0, XRrigUtilities.GetXRcam().position - XRrigUtilities.GetXRcam().up * 0.05f);
			GazeRayRenderer.SetPosition(1, XRrigUtilities.GetXRcam().position + gazeDirectionCombined * LengthOfRay);
		} 
	}
}
